<?php
error_reporting(0);
session_start();

if (!isset($_SESSION['id'])) {
  header("Location: index.php");
  exit;
}
else{
	//echo $_SESSION['id'];
	include "config.php";
$msg = '';
if(isset($_POST['add_category'])){
	$rand = rand();
	$category_name = $_POST['category_name'];
	$category_image = $rand."_".$_FILES['category_image']['name'];
	$full_path = IMAGE_PATH.$category_image;
	
	$category_insert = mysqli_query($con,"INSERT INTO app_category (category_name,category_image) VALUES('".$category_name."','".$full_path."')");
	//$category_search=mysqli_query($con, "SELECT * FROM app_category");
		
	if($category_image != '' && $category_insert != ''){
		//$category_search=mysqli_query($con, "SELECT * FROM app_category");
		$category_search = mysqli_query($con,"SELECT * FROM app_category WHERE category_name='".$category_name."'");
		$name = $rand."_".$_FILES['category_image']['name'];
		$full_path = IMAGE_PATH.$name;
		$size = $_FILES['category_image']['size'];
		$type = $_FILES['category_image']['type'];
		$tmp_name = $_FILES['category_image']['tmp_name'];

		 if (isset($name)){
			if (!empty($name)) 
			{
				if(move_uploaded_file($tmp_name, PDF_UPLOADS. $name)){
					$msg = "<p class='success'>New Church Group added.</p>";
					}
			}
			else 
			{
				$msg = "<p class='login_error'>Please choose a file.</p>";
			}

		}
	}
	else{
		$msg = "<p class='login_error'>Church Group not inserted.</p>";
	}

}

?>
<!DOCTYPE HTML>
<html>
<?php include "header.php"; ?>
<body>
   <div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<?php include "main-header.php"; ?>
					<!-- //header-ends -->
						<div class="container breadcrum-wrapper">
							<div class="row">
								<div class="col-md-12">
									<div class="col-md-12">
										<h3 class="breadcrumbs-title">ADD NEW CHURCH GROUP</h3>
										<ol class="breadcrumb">
											<li><a href="dashboard.php">HOME</a></li>
											<li><a href="about.php">ABOUT</a></li>
											<li><a href="category.php">CHURCH GROUPS</a></li>
											<li><a href="news.php">NEWS LIST</a></li>
											<li><a href="notification.php">PUBLISH NOTICES</a></li>
											<li><a href="admin.php">UPDATE PROFILE</a></li>
											<li><a href="http://www.cocin.org" target="_blank">VISIT COCIN WEBSITE</a></li>
											<li><a href="statistics.php">STATISTICS</a></li>
		
											<li><a href="category.php">GO BACK</a></li>
											<li><a href="logout.php">LOGOUT</a></li>
											<li><a href="#" class="active_page">NEW GROUP</a></li>
											
										</ol>
									</div>
								</div>
							</div>
						</div>
						<div class="outter-wp">
							<!--//outer-wp-->
							<div class="card-panel">
								<div class="row">
									<div class="row col-md-12">
										<form method="post" enctype="multipart/form-data" id="category_form">
											<?php if($msg != ''){
												echo $msg;
												}
											?>
											<div class="form-group col-md-12">
												<label>Group Name</label>
												<input type="text" class="form-control" name="category_name" id="category_name" required>
											</div>
											<div class="form-group col-md-12">
												<label>Image</label>
												<input type="file" name="category_image" id="category_image"  required>
											</div>
											<div class="col-md-12">
												<input type="submit" name="add_category" value="SUBMIT" class="right">
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
						 <!--footer section start-->
							<?php include "footer.php"; ?>
						<!--footer section end-->
					</div>
				</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
				<?php include "sidebar.php"; ?>
</body>
</html>

<?php
}
?>