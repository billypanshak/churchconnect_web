<?php
error_reporting(0);
session_start();

if (!isset($_SESSION['id'])) {
  header("Location: index.php");
  exit;
}
else{
	//echo $_SESSION['id'];
	include "config.php";
if(isset($_GET['id'])){
	$category_id = $_GET['id'];
$category_id=base64_decode($category_id);

}
	
if(isset($_POST['submit'])){
	$delete_query = mysqli_query($con,"DELETE FROM `app_category` WHERE id='".$category_id."'");
	if($delete_query){
		header("Location: category.php");
	}
}
?>
<!DOCTYPE HTML>
<html>
<?php include "header.php"; ?>
<body>
   <div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<?php include "main-header.php"; ?>
					<!-- //header-ends -->
		   			<div class="container breadcrum-wrapper">
							<div class="row">
								<div class="col-md-12">
									<div class="col-md-12">
										<h3 class="breadcrumbs-title">DELETE CHURCH GROUP</h3>
										<ol class="breadcrumb">
											<li><a href="dashboard.php">HOME</a></li>
											<li><a href="#">ABOUT</a></li>
											<li><a href="category.php">CHURCH GROUPS</a></li>
											<li><a href="news.php">NEWS LIST</a></li>
											<li><a href="notification.php">PUBLISH NOTICES</a></li>
											<li><a href="admin.php">UPDATE PROFILE</a></li>
											<li><a href="http://www.cocin.org" target="_blank">VISIT COCIN WEBSITE</a></li>
											<li><a href="statistics.php">STATISTICS</a></li>
											<li><a href="category.php">GO BACK</a></li>
											<li><a href="logout.php">LOGOUT</a></li>
											<li><a href="#" class="active_page">DELETE GROUP</a></li>
										</ol>
									</div>
								</div>
							</div>
						</div>
						<div class="outter-wp">
							<div class=" col-md-12">
							<!--//outer-wp-->
								<div class="card-panel">
									<div class="row">
										<div class="row">
											<form method="post">
												<div class="col-md-12">
													<p class="delete_line">Are you sure want to delete this Group?
												</div>
												<div class="col-md-12">
													<button type="submit" name="submit" class="btn view_buttons">DELETE</button>
													<a href="category.php"><button type="button" class="btn view_buttons">CANCEL</button></a>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						 <!--footer section start-->
							<?php include "footer.php"; ?>
						<!--footer section end-->
					</div>
				</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
				<?php include "sidebar.php"; ?>
</body>
</html>

<?php
}
?>