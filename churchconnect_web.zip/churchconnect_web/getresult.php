<?php
error_reporting(0);
require_once("config.php");
require_once("pagination.class.php");
$db_handle = new DBController();
$perPage = new PerPage();

$sql = "SELECT * from app_category";
$paginationlink = "getresult.php?page=";	
$pagination_setting = $_GET["pagination_setting"];
				
$page = 1;
if(!empty($_GET["page"])) {
$page = $_GET["page"];
}

$start = ($page-1)*$perPage->perpage;
if($start < 0) $start = 0;

$query =  $sql . " limit " . $start . "," . $perPage->perpage; 
$faq = $db_handle->runQuery($query);

if(empty($_GET["rowcount"])) {
$_GET["rowcount"] = $db_handle->numRows($sql);
}

if($pagination_setting == "prev-next") {
	$perpageresult = $perPage->getPrevNext($_GET["rowcount"], $paginationlink,$pagination_setting);	
} else {
	$perpageresult = $perPage->getAllPageLinks($_GET["rowcount"], $paginationlink,$pagination_setting);	
}


$output = '';


 ?><style>
.link {padding: 10px 15px;background: transparent;border:#bccfd8 1px solid;border-left:0px;cursor:pointer;color:#607d8b}
.disabled {cursor:not-allowed;color: #bccfd8;}
.current {background: #bccfd8;}
.first{border-left:#bccfd8 1px solid;}
.question {font-weight:bold;}
.answer{padding-top: 10px;}
#pagination{margin-top: 20px;padding-top: 30px;border-top: #F0F0F0 1px solid;}
.dot {padding: 10px 15px;background: transparent;border-right: #bccfd8 1px solid;}
#overlay {background-color: rgba(0, 0, 0, 0.6);z-index: 999;position: absolute;left: 0;top: 0;width: 100%;height: 100%;display: none;}
#overlay div {position:absolute;left:50%;top:50%;margin-top:-32px;margin-left:-32px;}
.page-content {padding: 20px;margin: 0 auto;}
.pagination-setting {padding:10px; margin:5px 0px 10px;border:#bccfd8  1px solid;color:#607d8b;}

</style>
 
 <div class="card-panel">
								<div class="row">
									<div class="row">
										<div class="col-md-12">
											<table  id="myTable" class="table table-hover news_table footable " data-page-size="6" data-first-text="FIRST" data-next-text="NEXT" data-previous-text="PREVIOUS" data-last-text="LAST">
												<thead>
													<tr>
														
														<th>Name</th>
														<th>Image</th>
														<th>Action</th>
													</tr>
												</thead>
												<tbody>
													<?php if (is_array($faq) || is_object($faq))
{ foreach($faq as $k=>$v) { ?>
													<tr>
														
														<td class="all_titles"><?php echo  $faq[$k]['category_name']; ?></td>
														<td><img class="img-responsive" width="80" height="80" src="<?php echo  $faq[$k]['category_image']; ?>"></td>
														<td>
															<a href="category-edit.php?id=<?php echo  base64_encode($faq[$k]['id']); ?>"><i class="fa fa-pencil" aria-hidden="true"></i>(Edit)</a>
															<a href="category-delete.php?id=<?php echo  base64_encode($faq[$k]['id']); ?>"><i class="fa fa-trash-o" aria-hidden="true"></i>(Delete)</a>
														</td>
													</tr>
										<?php $count = $count + 1; }}else { echo '<center><h2><br> No result to display. Please add First category.</h2></center>'; } ?>
												</tbody>
<tfoot class="hide-if-no-paging">
            <td colspan="5">
                <div class="pagination"></div>
            </td>
            </tfoot>
											</table>
											<div class="col-md-12">
												 <?php
if(!empty($perpageresult)) {
$output .= '<div id="pagination">' . $perpageresult . '</div>';
}
print $output;
?>
																							</div>
										</div>
									</div>
								</div>
							</div>
						</div><script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}


</script>
	
 

