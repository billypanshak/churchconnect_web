<?php
include_once("config.php");

if($_REQUEST['newsid']) {
$sql = "SELECT image FROM app_news WHERE id='".$_REQUEST['newsid']."'";
$resultset = mysqli_query($con, $sql) or die("database error:". mysqli_error($conn));
$data = array();
while( $rows = mysqli_fetch_assoc($resultset) ) {
$data = $rows;
}
echo json_encode($data,JSON_UNESCAPED_SLASHES);
} else {
echo 0;
}
?>
