<?php
error_reporting(0);
session_start();
include "config.php";
if (!isset($_SESSION['id'])) {
  header("Location: index.php");
  exit;
}
else{
	//echo $_SESSION['id'];

$fetch_category = mysqli_query($con,"SELECT * FROM `app_category`");
$categoryCount = mysqli_num_rows($fetch_category);
	
$fetch_news = mysqli_query($con,"SELECT * FROM `app_news`");
$newsCount = mysqli_num_rows($fetch_news);
	
?>
<!DOCTYPE HTML>
<html>
<?php include "header.php"; ?>
<body>
   <div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<?php include "main-header.php"; ?>
					<!-- //header-ends -->
		   				<div class="container breadcrum-wrapper">
							<div class="row">
								<div class="col-md-12">
									<div class="col-md-12">
										<h3 class="breadcrumbs-title">HOME</h3>
										<ol class="breadcrumb">
											<li><a href="#" class="active_page">HOME</a></li>
											<li><a href="about.php">ABOUT</a></li>
											<li><a href="category.php">CHURCH GROUPS</a></li>
											<li><a href="news.php">NEWS LIST</a></li>
											<li><a href="notification.php">PUBLISH NOTICES</a></li>
											<li><a href="admin.php">UPDATE PROFILE</a></li>
											<li><a href="http://www.cocin.org" target="_blank">VISIT COCIN WEBSITE</a></li>
											<li><a href="statistics.php">STATISTICS</a></li>
											<li><a href="logout.php">LOGOUT</a></li>
										</ol>
									</div>
								</div>
							</div>
						</div>
						<div class="outter-wp">
							<!--input slide show here-->
						<div class="container2">
							<div class="row">
								<div class="col-sm-12">
									<div id="my-slider" class="carousel slide" data-ride="carousel">

											<!--indicators dot nav-->
											<ol class="carousel-indicators">
												<li data-target="#my-slider" data-slide-to="0" class="active"></li>
												<li data-target="#my-slider" data-slide-to="1"></li>
												<li data-target="#my-slider" data-slide-to="2"></li>
												<li data-target="#my-slider" data-slide-to="3"></li>
												<li data-target="#my-slider" data-slide-to="4"></li>
												<li data-target="#my-slider" data-slide-to="5"></li>
												<li data-target="#my-slider" data-slide-to="6"></li>
											</ol>
											<!--wrapper for slides-->
											<div class="carousel-inner" role="listbox">
												<div class="item active">
													<img src="images/slide1.jpg" alt="slide1"/>
													<!--adding a caption-->
													<div class="carousel-caption"><h5>Image 1</h5>
													</div>
												</div>
												<div class="item">
													<img src="images/slide2.jpg" alt="slide2"/>
													<!--adding a caption-->
													<div class="carousel-caption"><h5>Image 2</h5>
														<p>Everything happens for a reason!! Lets learn to appreciate God</p>
													</div>
												</div>
												<div class="item">
													<img src="images/slide3.jpg" alt="slide3"/>
													<!--adding a caption-->
													<div class="carousel-caption"><h5>Image 3</h5></div>
												</div>
												<div class="item">
													<img src="images/slide4.jpg" alt="slide4"/>
													<!--adding a caption-->f
													<div class="carousel-caption"><h5>Image 4</h5></div>
												</div>
												<div class="item">
													<img src="images/slide5.jpg" alt="slide5"/>
													<!--adding a caption-->
													<div class="carousel-caption"><h6>Image 5</h6></div>
												</div>
												<div class="item">
													<img src="images/slide6.jpg" alt="slide6"/>
													<!--adding a caption-->
													<div class="carousel-caption"><h6>Image 6</h6></div>
												</div>
												<div class="item">
													<img src="images/slide7.jpg" alt="slide7"/>
													<!--adding a caption-->
													<div class="carousel-caption"><h6>Image 7</h6></div>
												</div>
												
											</div>
											<!--controls or next and previous buttons-->
											<a class="left carousel-control" href="#my-slider" role="button" data-slide="prev">
												<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
											</a>
											<a class="right carousel-control" href="#my-slider" role="button" data-slide="next">
												<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
											</a>
										</div>
										
									</div>
										
								</div>
							</div>
					

						<!--end of slide-->	
						</div>
						 <!--footer section start-->
							<?php include "footer.php"; ?>
						<!--footer section end-->
					</div>
				</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
	</div>			
<?php include "sidebar.php"; ?>
</body>
</html>
<?php
}
?>