<?php
error_reporting(0);
session_start();

if (!isset($_SESSION['id'])) {
  header("Location: index.php");
  exit;
}

?>

<!DOCTYPE HTML>
<html>
<?php include "header.php"; ?>
<body>
<div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<?php include "main-header.php"; ?>
					<!-- //header-ends -->
		   				<div class="container breadcrum-wrapper">
							<div class="row">
								<div class="col-md-12">
									<div class="col-md-12">
										<h3 class="breadcrumbs-title">ABOUT THE APPLICATION</h3>
										<ol class="breadcrumb">
											<li><a href="dashboard.php">HOME</a></li>
											<li><a href="#" class="active_page">ABOUT</a></li>
											<li><a href="category.php">CHURCH GROUPS</a></li>
											<li><a href="news.php">NEWS LIST</a></li>
											<li><a href="notification.php">PUBLISH NOTICES</a></li>
											<li><a href="admin.php">UPDATE PROFILE</a></li>
											<li><a href="http://www.cocin.org" target="_blank">VISIT COCIN WEBSITE</a></li>
											<li><a href="statistics.php">STATISTICS</a></li>
											<li><a href="dashboard.php">GO BACK</a></li>
											<li><a href="logout.php">LOGOUT</a></li>
										</ol>
									</div>
								</div>
							</div>
						</div>
		   				<div class="outter-wp">
							<!--//outer-wp-->
							<div class="card-panel">
								<div class="row">
									<div class="col-md-12">
										<p>This application is designed for creating, maintaining, and sending/publishing notices/news partaining the welfare of the Church; which will be received, viewed and read by the entire users (members of COCIN LCC Mado) who are using an Android app version of the application
									</div>
								</div>
							</div>
		   				</div>
						 <!--footer section start-->
							<?php include "footer.php"; ?>
						<!--footer section end-->
					</div>
				</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
				<?php include "sidebar.php"; ?>
</body>
</html>