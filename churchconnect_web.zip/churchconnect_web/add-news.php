<?php
error_reporting(0);
session_start();
if (!isset($_SESSION['id'])) {
  header("Location: index.php");
  exit;
}
else{
	$msg = '';
	include "config.php";

?>
<?php	
if(isset($_POST['submit'])){
	$rand = rand();
	$news_title=$_POST['news-title'];
	//$news_title = preg_replace('/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s', '', $news_title);
$remove[] = "'";
$remove[] = "`";
$remove[] = '"';
$remove[] = "-"; // just as another example
$news_title = str_replace( $remove, "", $news_title ); 

$news_title=htmlspecialchars($news_title);
	$news_category = $_POST['news-category'];
	$news_date = $_POST['news-date'];
	//$news_image1 = $rand."_".$_FILES['news-image']['name'];
        $new=rand(99,10000);
        $news_image=$new.preg_replace('/\s/', '',$_FILES['news-image']['name']);
	$Editor1 = htmlspecialchars($_POST['editor1']);
	
	
	if($news_image != ''){
		$name = $new.preg_replace('/\s/', '',$_FILES['news-image']['name']);
		$full_path = IMAGE_PATH.$name;
		$size = $_FILES['news-image']['size'];
		$type = $_FILES['news-image']['type'];
		$tmp_name = $_FILES['news-image']['tmp_name'];


		 if (isset($name)) 
		{
			if (!empty($name)) 
			{
				if(move_uploaded_file($tmp_name, PDF_UPLOADS. $name)){
					'<p class="success">Your news is added successfully.</p>';
				}
			}

		}
	}
	
	$news_insert = mysqli_query($con,"INSERT INTO app_news (title,category,date,image,description) VALUES('".$news_title."','".$news_category."','".$news_date."','".$full_path."','".$Editor1."')");
	
	if($news_insert){
		$msg = '<p class="success">Your news is added successfully.</p>';
	}

}
?>    
<!DOCTYPE HTML>
<html>
<?php include "header.php"; ?>
<body>
   <div class="page-container">
    <!--/content-inner-->
    <div class="left-content">
        <div class="inner-content">
            <!-- header-starts -->
            <?php include "main-header.php"; ?>
                <!-- //header-ends -->
				<div class="container breadcrum-wrapper">
					<div class="row">
						<div class="col-md-12">
							<div class="col-md-12">
								<h3 class="breadcrumbs-title">ADD NEWS</h3>
								<ol class="breadcrumb">
									<li><a href="dashboard.php">HOME</a></li>
									<li><a href="about.php">ABOUT</a></li>
									<li><a href="category.php">CHURCH GROUPS</a></li>
									<li><a href="news.php">NEWS LIST</a></li>
									<li><a href="notification.php">PUBLISH NOTICES</a></li>
									<li><a href="admin.php">UPDATE PROFILE</a></li>
									<li><a href="http://www.cocin.org" target="_blank">VISIT COCIN WEBSITE</a></li>
									<li><a href="statistics.php">STATISTICSS</a></li>
									<li><a href="news.php">GO BACK</a></li>
									<li><a href="logout.php">LOGOUT</a></li>
									<li><a href="#" class="active_page">ADD NEWS</a></li>
									
								</ol>
							</div>
						</div>
					</div>
				</div>
                <div class="outter-wp">
                    <div class=" col-md-12 card-panel">
						<form method="post" enctype="multipart/form-data">
							<?php if($msg != ''){
								echo $msg;
							}
							?>
							<div class=" col-md-5">
								<div class="form-group">
									<label for="title">News Title</label>
									<input type="text" name="news-title" class="form-control" required>
								</div>
								<div class="form-group">
									<label for="select_cat">Select Church Group</label>
									<select name="news-category" class="form-control select_cat" required>
										<option></option>
										<?php
								$cats = mysqli_query($con,"SELECT * FROM `app_category`");
								while($rows = mysqli_fetch_array($cats)){
										?>
										<option value="<?php echo $rows['id']; ?>"><?php echo ucfirst($rows['category_name']); ?></option>
								<?php } ?>
									</select>
								</div>
								<div class="form-group">
									<label for="date">News Date</label>
									<input type="date" name="news-date" class="form-control" required>
								</div>
								<div class="form-group">
									<label for="image">Image</label>
									<input type="file" name="news-image" id="news-image" required>
								</div>								
							</div>
							<div class=" col-md-7">
								<textarea name="editor1" id="editor1" rows="10" cols="80">
									
								</textarea>
								<script src="ckeditor/ckeditor.js"></script>
								<script>
									// Replace the <textarea id="editor1"> with a CKEditor
									// instance, using default configuration.
									
									CKEDITOR.replace( 'editor1' );
								</script>
							</div>
							<input type="submit" name="submit" value="ADD" class="add_news">
						</form>
                    </div>
                    <!--//outer-wp-->
                </div>
                <!--footer section start-->
                <?php include "footer.php"; ?>
                    <!--footer section end-->
        </div>
    </div>
    <!--//content-inner-->
    <!--/sidebar-menu-->
    <?php include "sidebar.php"; ?>
</body>
</html>

<?php
}
?>