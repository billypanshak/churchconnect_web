<?php
error_reporting(0);
session_start();

if (!isset($_SESSION['id'])) {
  header("Location: index.php");
  exit;
}
else{
	//echo $_SESSION['id'];
	include "config.php";

?>
<!DOCTYPE HTML>
<html>
<?php include "header.php"; ?>
<body>
   <div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<?php include "main-header.php"; ?>
					<!-- //header-ends -->
		   				<div class="container breadcrum-wrapper">
							<div class="row">
								<div class="col-md-12">
									<div class="col-md-12">
										<h3 class="breadcrumbs-title">Category List</h3>
										<ol class="breadcrumb">
											<li><a href="dashboard.php">Dashboard</a></li>
											<li><a href="#" class="active_page">Manage category</a></li>
										</ol>
									</div>
								</div>
							</div>
						</div>
						<div class="outter-wp">
							<div class=" col-md-12">
								<div class="col-md-4">
									<a href="add-category.php" class="add_news">Add New Category</a>
								</div>											
								<div class="col-md-4">
									<input type="text" class="validate" name="keyword">
									<label for="search_keyword" id="label" class="">Search</label>
								</div>
								<div class="col-md-4">
									<button type="submit" name="btnSearch" class="search_button"><i class="fa fa-search" aria-hidden="true"></i></button>
								</div>
							</div>
							<!--//outer-wp-->
							<div class="card-panel">
								<div class="row">
									<div class="row">
										<div class="col-md-12">
											<table class="table table-hover news_table">
												<thead>
													<tr>
														<th>Name</th>
														<th>Image</th>
														<th>Action</th>
													</tr>
												</thead>
												<tbody>
													<?php
										$fetch_news = mysqli_query($con,"SELECT * FROM `app_category`");
										$count = 0;
										while($row = mysqli_fetch_array($fetch_news)){											
													?>
													<tr>
														<td class="all_titles"><?php echo $row['category_name']; ?></td>
														<td><img class="img-responsive" width="80" height="80" src="<?php echo IMAGE_PATH.$row['category_image']; ?>"></td>
														<td>
															<a type="button" class="btn btn-primary" href="category-edit.php?id=<?php echo $row['id']; ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>
															<a href="category-delete.php?id=<?php echo $row['id']; ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
														</td>
													</tr>
										<?php $count = $count + 1; } ?>
												</tbody>
											</table>
											<div class="col-md-12">
												<h3 class="total_count"><?php echo "( total ".$count." )"; ?></h3>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						 <!--footer section start-->
							<?php include "footer.php"; ?>
						<!--footer section end-->
					</div>
				</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
				<?php include "sidebar.php"; ?>
</body>
</html>

<?php
}
?>