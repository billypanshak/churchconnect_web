<?php
error_reporting(0);
session_start();

if (!isset($_SESSION['id'])) {
  header("Location: index.php");
  exit;
}
else{
	$msg = '';
	include "config.php";
if(isset($_GET['id'])){
	$news_id = $_GET['id'];
$news_id=base64_decode($news_id);
}
$rand = rand();
$view_query = mysqli_query($con,"SELECT * FROM `app_news` WHERE id='".$news_id."'");
while($row = mysqli_fetch_array($view_query)){
	$title = $row['title'];
	$cat_id = $row['category'];
	$image = $row['image'];
	$date = $row['date'];
	$description = htmlspecialchars_decode($row['description']);
	
	$cat_query = mysqli_query($con,"SELECT * FROM app_category WHERE id ='".$cat_id."'");
	while($cat_data = mysqli_fetch_array($cat_query)){
		$cat_name = $cat_data['category_name'];
	}
}

if(isset($_POST['submit'])){
	$title1 = $_POST['news-title'];
$remove[] = "'";
$remove[] = "`";

 // just as another example
$title1 = str_replace( $remove, "", $title1 );   
        $title=htmlspecialchars($title1);
//echo $title;
	$cat_id = $_POST['news-category'];	
	$date = $_POST['news-date'];
	$description = htmlspecialchars($_POST['editor1']);
	
	if($_FILES['news-image']['name'] != ''){
		$image = $rand."_".$_FILES['news-image']['name'];
		$full_path = IMAGE_PATH.$image;
		$update = mysqli_query($con,"UPDATE app_news SET title='".$title."', category='".$cat_id."', date='".$date."', image='".$full_path."', description='".$description."' WHERE id='".$news_id."'") or mysqli_error();
	}
	else{
		$update = mysqli_query($con,"UPDATE app_news SET title='".$title."', category='".$cat_id."', date='".$date."',description='".$description."' WHERE id='".$news_id."'") or mysqli_error();
	}
	if($_FILES['news-image']['name'] != '' && $update != ''){
		$name = $rand."_".$_FILES['news-image']['name'];
		$size = $_FILES['news-image']['size'];
		$type = $_FILES['news-image']['type'];
		$tmp_name = $_FILES['news-image']['tmp_name'];


		 if (isset($name)) 
		{
			if (!empty($name)) 
			{
				if(move_uploaded_file($tmp_name, PDF_UPLOADS. $name))
					$msg = '<p class="success">Your News is updated. Please go <span class="back"><a href="news.php">back</a></span> or open News again to see it.</p>';
				else
					$msg = "<p class='login_error'>Your News is not updated.</p>";
			}
		}
	}
	else if($update != ''){
		$msg = '<p class="success">Your News is updated. Please go <span class="back"><a href="news.php">back</a></span> or open News again to see it.</p>';
	}
}
?>
<!DOCTYPE HTML>
<html>
<?php include "header.php"; ?>
<body>
   <div class="page-container">
    <!--/content-inner-->
    <div class="left-content">
        <div class="inner-content">
            <!-- header-starts -->
            <?php include "main-header.php"; ?>
                <!-- //header-ends -->
				<div class="container breadcrum-wrapper">
					<div class="row">
						<div class="col-md-12">
							<div class="col-md-12">
								<h3 class="breadcrumbs-title">EDIT NEWS</h3>
								<ol class="breadcrumb">
									<li><a href="dashboard.php">HOME</a></li>
									<li><a href="about">ABOUT</a></li>
									<li><a href="category.php">CHURCH GROUPS</a></li>
									<li><a href="news.php">NEWS LIST</a></li>
									<li><a href="notification.php">PUBLISH NOTICES</a></li>
									<li><a href="admin.php">UPDATE PROFILE</a></li>
									<li><a href="http://www.cocin.org" target="_blank">VISIT COCIN WEBSITE</a></li>										
									<li><a href="statistics.php">STATISTICS</a></li>
									<li><a href="news.php">GO BACK</a></li>
									<li><a href="logout.php">LOGOUT</a></li>
									<li><a href="#" class="active_page">EDIT NEWS</a></li>
								</ol>
							</div>
						</div>
					</div>
				</div>
                <div class="outter-wp">
                    <div class=" col-md-12 card-panel">
						<form method="post" enctype="multipart/form-data">
							<?php if($msg != ''){
								echo $msg;
							}
							?>
							<div class=" col-md-5">
								<div class="form-group">
									<label for="title">News Title</label>
									<input type="text" name="news-title" value="<?php echo $title; ?>" class="form-control">
								</div>
								<div class="form-group">
									<select name="news-category" class="form-control select_cat">
										<option value="">---------</option>
										<?php
								$cats = mysqli_query($con,"SELECT * FROM `app_category`");
								while($rows = mysqli_fetch_array($cats)){
										?>
										<option value="<?php echo $rows['id']; ?>" <?php if($cat_id == $rows['id']){ echo "selected = selected"; } ?>><?php echo ucfirst($rows['category_name']); ?></option>
								<?php } ?>
									</select>
								</div>
								<div class="form-group">
									<label for="date">News Date</label>
									<input type="date" name="news-date" value="<?php echo $date; ?>" class="form-control">
								</div>
								<div class="form-group">
									<img src="<?php echo $image; ?>" width="210" height="130">
								</div>
								<div class="form-group">
									<label for="image">Image</label>
									<input type="file" name="news-image" id="news-image">
								</div>
							</div>
							<div class=" col-md-7">
								<textarea name="editor1" id="editor1" rows="10" cols="80">
									<?php echo $description; ?>
								</textarea>
								<script src="ckeditor/ckeditor.js"></script>
								<script>
									// Replace the <textarea id="editor1"> with a CKEditor
									// instance, using default configuration.
									CKEDITOR.replace( 'editor1' );
								</script>
							</div>
							<input type="submit" name="submit" value="UPDATE" class="edit_news">
						</form>
                    </div>
                    <!--//outer-wp-->
                </div>
                <!--footer section start-->
                <?php include "footer.php"; ?>
                    <!--footer section end-->
        </div>
    </div>
    <!--//content-inner-->
    <!--/sidebar-menu-->
    <?php include "sidebar.php"; ?>
</body>
</html>

<?php
}
?>