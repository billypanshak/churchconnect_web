<?php
error_reporting(0);
session_start();
$session_user_id=$_SESSION['id'];
if (!isset($_SESSION['id'])) {
  header("Location: index.php");
  exit;
}
else{
	$msg = '';
	include "config.php";

	$admin_details = mysqli_query($con,"SELECT * FROM `app_login`  WHERE `id`= $session_user_id");
	while($row = mysqli_fetch_array($admin_details)){
		$email = $row['email'];
		$password = $row['password'];
	}
	
	if(isset($_POST['submit'])){
		$email = $_POST['email'];
		$old_pwd = md5($_POST['old_pwd']);
		$new_pwd = $_POST['new_pwd'];
		$confirm_pwd = $_POST['confirm_pwd'];
		$new_pwd_hash = md5($confirm_pwd);

		//code to check if email or username already exist
		//get all usernames and emails emails from the database and check if they already exist
			$result=mysqli_query($con,"SELECT * FROM app_login");
			if (!$result){
				//die("Database query failed: ".mysql_error());
				$msg ='<font color=blue size=4>Sorry! we are having a problem connecting to database.<br>
				Try again later</font>';
			}
			$bool=false;
			while($row = mysqli_fetch_array($result)){
					if($email == $row["email"]){
						$bool=true;
					}
				
				}

		//end of code

		 if($password != $old_pwd){
			$msg = "<p class='login_error'>Old Password entered is incorrect.</p>";
		}
		/*else if($bool==true){
				$msg = '<font color=red size=3><p class="login_error">Sorry, the email</font> \' ' .$_POST['email']. ' \'<font color=red size=4> already exists!!</p></font>';
			}
		*/
	 	else if(strlen($_POST['new_pwd'])<6){
	 			$msg = '<font color=red size=3><p class="login_error">Your password must be atleast 6 characters </p></font>';
	 		}
		else if($new_pwd != $confirm_pwd){
			$msg = "<p class='login_error'>New password and confirm password do not match.</p>";
		}
		else if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) === false){
	 			$msg = '<font color=red size=3><p class="login_error">A valid email address is required</p></font>';
	 		}

	 	/*else if($bool2==true){
				$msg = '<font color=red size=3><p class="login_error">Sorry, the email</font> \' ' .$_POST['email']. ' \'<font color=red size=4> already exists!!</p></font>';
			}
		else if($bool==true){
				$msg = '<font color=red size=3><p class="login_error">Sorry, the username</font> \' ' .$_POST['username']. ' \'<font color=red size=4>already exists!!</p></font>';
			}*/
		else{
			$update_admin = mysqli_query($con,"UPDATE `app_login` SET email='".$email."', password='".$new_pwd_hash."' WHERE `id`= $session_user_id");
			if($update_admin){
				$msg = "<p class='success'>Your details have been updated successfully.</p>";
			}
		
	}
}
	
?>
<!DOCTYPE HTML>
<html>
<?php include "header.php"; ?>
<body>
   <div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<?php include "main-header.php"; ?>
					<!-- //header-ends -->
		   				<div class="container breadcrum-wrapper">
							<div class="row">
								<div class="col-md-12">
									<div class="col-md-12">
										<h3 class="breadcrumbs-title">UPDATE PROFILE</h3>
										<ol class="breadcrumb">
											<li><a href="dashboard.php">HOME</a></li>
											<li><a href="about.php">ABOUT</a></li>
											<li><a href="category.php">CHURCH GROUPS</a></li>
											<li><a href="news.php">NEWS LIST</a></li>
											<li><a href="notification.php">PUBLISH NOTICES</a></li>
											<li><a href="#" class="active_page">UPDATE PROFILE</a></li>
											<li><a href="http://www.cocin.org" target="_blank">VISIT COCIN WEBSITE</a></li>
											<li><a href="statistics.php">STATISTICS</a></li>
											<li><a href="dashboard.php">GO BACK</a></li>
											<li><a href="logout.php">LOGOUT</a></li>
										</ol>
									</div>
								</div>
							</div>
						</div>
						<div class="outter-wp">							
							<!--//outer-wp-->
							<div class="card-panel">
								<div class="">
									<div class="row">
										<div class="col-md-12">
											<?php if($msg != ''){
													echo $msg;
												}
											?>
											<form method="post">
												<div class="form-group">
													<label for="email">Email Address:</label>
													<input type="email" name="email" class="form-control" id="email" value="<?php echo $email; ?>" required>
												</div>
												<div class="form-group">
													<label for="old_pwd">Old Password:</label>
													<input type="password" name="old_pwd" class="form-control" id="old_pwd" required>
												</div>
												<div class="form-group">
													<label for="new_pwd">New Password:</label>
													<input type="password" name="new_pwd" class="form-control" id="new_pwd" required>
												</div>
												<div class="form-group">
													<label for="confirm_pwd">Confirm Password:</label>
													<input type="password" name="confirm_pwd" class="form-control" id="confirm_pwd" required>
												</div>
												<button type="submit" name="submit" class="btn btn-default right">UPDATE</button>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						 <!--footer section start-->
							<?php include "footer.php"; ?>
						<!--footer section end-->
					</div>
				</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
				<?php include "sidebar.php"; ?>
</body>
</html>

<?php
}
?>