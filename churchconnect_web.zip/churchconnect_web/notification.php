<?php
error_reporting(0);
session_start();

if (!isset($_SESSION['id'])) {
  header("Location: index.php");
  exit;
}else{
$msg = '';
	include "config.php";

?>

<!DOCTYPE HTML>
<html>
<?php include "header.php"; ?>
<body>
<div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<?php include "main-header.php"; ?>
					<!-- //header-ends -->
		   				<div class="container breadcrum-wrapper">
							<div class="row">
								<div class="col-md-12">
									<div class="col-md-12">
										<h3 class="breadcrumbs-title">PUBLISH NOTICES</h3>
										<ol class="breadcrumb">
											<li><a href="dashboard.php">HOME</a></li>
											<li><a href="about.php">ABOUT</a></li>
											<li><a href="category.php">CHURCH GROUPS</a></li>
											<li><a href="news.php">NEWS LIST</a></li>
											<li><a href="#" class="active_page">PUBLISH NOTICES</a></li>
											<li><a href="admin.php">UPDATE PROFILE</a></li>
											<li><a href="http://www.cocin.org" target="_blank">VISIT COCIN WEBSITE</a></li>
											<li><a href="statistics.php">STATISTICS</a></li>
											<li><a href="dashboard.php">GO BACK</a></li>
											<li><a href="logout.php">LOGOUT</a></li>
										</ol>
									</div>
								</div>
							</div>
						</div>
		   				<div class="outter-wp">
							<!--//outer-wp-->
							<div class="card-panel">
								<div class="row">
									<div class="col-md-12">
										



<form method="post" enctype="multipart/form-data" action="send.php">
							<?php if($msg != ''){
								echo $msg;
							}
							?>
							<div class=" col-md-5">
								<div class="form-group">
									<label for="title"> Title</label>
									<input type="text" name="title" placeholder="Enter your Title here"  class="form-control" required>
								</div>
								<div class="form-group">
<label for="title">Message</label>
<input type="text" name="msg" placeholder="Enter your Message here" class="form-control" required>
							</div>
                                                         <div class="form-group">
<label for="title">Select News</label><br>
							<select name="news" class="selectpicker" data-live-search="true" id="news" style="color: #fff;" title="Choose here..." required>
										
										<?php
								$cats = mysqli_query($con,"SELECT * FROM `app_news`");
								while($rows = mysqli_fetch_array($cats)){
										?>

										<option  class="text-dark" value="<?php echo $rows['id']; ?>" id="<?php echo $row['id'];?>"><?php echo ucfirst($rows['title']); ?></option>
								<?php } ?>
									</select>
								
<div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Image</label>
                  <br>
                  <div class="col-sm-10">
                  <script>
                  $(document).ready(function(){
// code to get all records from table via select box
$("#news").change(function() {
var defaultvari='loading.gif'
var id = $(this).find(":selected").val();
var dataString = 'newsid='+ id;
//alert(id);
$.ajax({
url: 'getimg.php',
dataType: "json",
data: dataString,
cache: false,
beforeSend: function(){
        $('#imm').show();
    },
success: function(d){
//alert(d.image); //will alert ok
   $('#imm').attr('src', d.image);
   var imageurl=d.image;
   $.post("send.php",{"imageurl":imageurl});
   //alert(imageurl);
  }
  

});
})
});
                  
                  </script>
          <img id = "imm" src="select-news-image.png" height="100" width="100">       
          
                  </div>
                </div>

          </div>
       
<br><br><br><input type="submit" class"btn btn-success" value="SEND NOW" >						
</form>
</div>
								</div>
							</div>
		   				</div>
						 <!--footer section start-->
							<?php include "footer.php"; ?>
						<!--footer section end-->
					</div>
				</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
				<?php include "sidebar.php"; }?>
</body>
</html>