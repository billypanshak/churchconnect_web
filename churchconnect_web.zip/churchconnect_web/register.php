
<?php
error_reporting(0);
include "config.php";
?>
<?php	
if(isset($_POST['register'])){
	$email = $_POST['email'];
	$password = $_POST['password'];
	$password_again = $_POST['password_again'];
	$password_hash=md5($password);//encripting password
	//get all usernames and emails emails from the database and check if they already exist
			$result=mysqli_query($con,"SELECT * FROM app_login");
			if (!$result){
				//die("Database query failed: ".mysql_error());
				$msg ='<font color=blue size=4>Sorry! we are having a problem connecting to database.<br>
				Try again later</font>';
			}
			$bool=false;
			$bool2=false;
			while($row = mysqli_fetch_array($result)){
					if($email == $row["email"]){
						$bool2=true;
					}
				
				}

	if(empty($email)==true || empty($password)==true || empty($password_again)==true){
			$msg = '<font color=red size=3>All fields are required!!</font>';

			// checking if username exist
		}
			//checking if email already exist
			else if($bool2==true){
				$msg = '<font color=red size=3>Sorry, the email</font> \' ' .$_POST['email']. ' \'<font color=red size=4> already exists!!</font>';
			}
	 		// checking user's password length
	 		else if(strlen($_POST['password'])<6){
	 			$msg = '<font color=red size=3>Your password must be atleast 6 characters</font>';
	 		}
	 		// checking user's password against password_again
	 		else if($_POST['password']!== $_POST['password_again']){
	 			$msg = '<font color=red size=3>Your passwords do not match</font>';
	 		}
	 		//Checking if email entered by user is a valid email address
	 		else if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) === false){
	 			$msg = '<font color=red size=3>A valid email address is required</font>';
	 		}
	 		

			else{
				$query=htmlentities(strip_tags(mysql_real_escape_string(mysqli_query($con, "INSERT INTO app_login (email, password) VALUES ('{$email}', '{$password_hash}')"))));
				//checking if user details have been inserted into the database successfully
				if($query=true){

					$msg = '<font color=green size=4> CONGRATULATIONS, you have successfully registered with the email address:  </font> \' ' .$_POST['email']. ' \'';
					header ("refresh:7; index.php" );
				}else{
					$msg = '<font color=red size=3> SORRY, </font> \' ' .$_POST['email']. ' \'
					<font color=red size=3> we are unable to register you.<br> Please try again later!!</font>';
					header ("refresh:10; index.php" );
		}
	}
}
mysqli_close($con);
?>	
<!DOCTYPE HTML>
<html>
<head>
<title>ChurchConnect Admin Register Page</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Augment Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<!-- //lined-icons -->
<script src="js/jquery-1.10.2.min.js"></script>
<!--clock init-->
</head> 
<body class="ash">
								<!--/login-->
								
	<div class="error_page">
	<!--/login-top-->
												
		<div class="error-top">
			<img src="logofinal.jpg" class="img-circle" width="150" height="150"  alt="Chania">				
			<div class="login">
				<h3 class="inner-tittle t-inner">COCIN LCC MADO ChurchConnect App <br> Admin Panel</h3>
				<h3 class="inner-tittle t-inner">Registration</h3>
				<?php
					if(!empty($msg)){
						echo "<p class='registration_error'>".$msg."</p>";
																			}
				?>
				<form action="#" method="post">
					<input type="text" class="text" placeholder="Email Address" name="email">
					<input type="password" placeholder="Password" name="password">
					<input type="password" placeholder="Password again" name="password_again">
					<div class="sign-up">
						<input type="reset" value="Reset">
						<input type="submit" value="SIGN UP" name="register">
					</div>
					<div class="clearfix"></div>
						<p class="sign">Already registered? <a href="index.php">LOGIN</a></p>
						<br>
						<p>&copy Billy Panshak Shippi</p>
				</form>
			</div>
														
		</div>
	</div>
	<!--footer section start-->
	<div class="footer">
	</div>	
	<!--footer section end-->
	<!--/404-->
	<!--js -->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.min.js"></script>
</body>
</html>