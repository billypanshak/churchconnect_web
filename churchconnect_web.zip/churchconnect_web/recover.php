
<?php
error_reporting(0);
include "config.php";
//creating some vital functions to facilitates account recovery process
		function sanitize($data){
		return htmlentities(strip_tags(mysql_real_escape_string($data)));
	}
	//creating the email function
	function email($to, $subject, $body){
		mail($to, $subject, $body, 'From:teamChurchConnect.net');
	}
	// creating a function to gather the currently logged in user's information
	function user_data($id){
		// creating am empty array to return the values we want
		$data= array();
		$id= (int) $id;
		// getting arguements from the fuction
		$func_num_args = func_num_args();

		$func_get_args = func_get_args();

		if($func_num_args>1){
			unset($func_get_args[0]);

			$fields ='`' .implode('`,`', $func_get_args) .'`';

			$data = mysql_fetch_assoc(mysql_query("SELECT $fields FROM `app_login` WHERE `id`=$id"));
			return $data;
		}
	}

		//creating a function that gets the user_id from the email.
	function user_id_from_email ($email) {
       $email = sanitize ($email);
        return mysql_result(mysql_query("SELECT `id` FROM `app_login` WHERE `email` = '$email'"), 0, 'id');
}

		//creating the function for email and password recovery
	function recover($mode, $email){
		$mode 		= sanitize($mode);
		$email 		= sanitize($email);

		$user_data	= user_data(user_id_from_email($email),'id', 'username');

		if($mode=='username'){
			//recover username
			// using the email function.
			email($email, 'Your username', "Hello, ".$user_data['username']. "\n\n Your username name for login in to the ChurchConnect Admin Application is: ".$user_data['username']);//this is the email function for sending mails
		} else if($mode=='password'){
			//recover password
			//generate a new password for the user
			$generated_password=substr(md5(rand(999,999999)), 0, 8);
			//there are some codes left out untill the site is lauched online then they would be included
			
		}
	}
//end of creation of vital functions
?>
<?php


if(isset($_POST['recover'])){
	$email = $_POST['email'];
	//get all emails from the database and check it agaist what the user has entered
			$result=mysqli_query($con,"SELECT * FROM app_login");
			if (!$result){
				//die("Database query failed: ".mysql_error());
				$msg ='<font color=blue size=4>Sorry! we are having a problem connecting to database.<br>
				Try again later</font>';
			}
			$bool=false;
			while($row = mysqli_fetch_array($result)){
				if ($email ==$row["email"]){
					$bool=true;
					}
				}

	if(empty($email)==true){
			$msg = '<font color=red size=3>Please you need to enter your email address</font>';
		}
		
			else if($bool==true){
						recover($_GET['mode'], $_POST['email']);//sending the email
						$msg = '<font color=green size=4> Thank you!!<br></font>
						<font color=green size=3>We have emailed you your password.</font>';
						header ("refresh:10; index.php" );		
			}
			else{
				$msg = '<font color=red size=3>Oops!! We could\'t find the email address</font> \' ' .$_POST['email']. ' \'<font color=red size=3>The email to enter must be the one you used upon registering</font>';
			
		}
}
mysqli_close($con);
?>	
<!DOCTYPE HTML>
<html>
<head>
<title>ChurchConnect Account Recovery Page</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Augment Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<!-- //lined-icons -->
<script src="js/jquery-1.10.2.min.js"></script>
<!--clock init-->
</head> 
<body class="ash">
								<!--/login-->
								
	<div class="error_page">
	<!--/login-top-->
												
		<div class="error-top">
			<img src="logofinal.jpg" class="img-circle" width="150" height="150"  alt="Chania">				
			<div class="login">
				<h3 class="inner-tittle t-inner">COCIN LCC MADO ChurchConnect App <br> Admin Panel</h3>
				<h3 class="inner-tittle t-inner">Account Recovery</h3>
				<?php
					$mode_allowed=array('username', 'password');
					if(isset($_GET['mode'])===true && in_array($_GET['mode'], $mode_allowed)===true){

					} else{
						header("Location:index.php");
						exit();

					}
				?>
				<?php
					if(!empty($msg)){
						echo "<p class='registration_error'>".$msg."</p>";
																			}
				?>
				<form action="#" method="post">
					
					<input type="text" class="text" placeholder="Enter your email address here" name="email">
					<input type="submit" value="RECOVER" name="recover">
					</div>
					<div class="clearfix"></div>
						<p class="sign"><a href="index.php">Go back to Login page</a></p>
						
						<p>&copy Billy Panshak Shippi</p>

				</form>
			</div>
														
		</div>
	</div>
	<!--footer section start-->
	<div class="footer">
	</div>	
	<!--footer section end-->
	<!--/404-->
	<!--js -->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.min.js"></script>
</body>
</html>