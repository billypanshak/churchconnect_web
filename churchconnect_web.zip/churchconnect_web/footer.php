

<style>
span#logo h1 {
    font-size: 1.5em !important;
    font-weight: 600 !important;
}
span.back a {
	font-size: 17px;
	color: green;
	font-weight: 600;
}.footertext {
    text-align: center;

}
</style>
<footer class="footertext">
<p><sub><a href="http://abhiandroid.com/"><font color="white" size="4">© Billy Panshak Shippi</font></sub></a>  </p>
</footer>