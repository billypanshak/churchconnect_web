<?php
error_reporting(0);
session_start();

if (!isset($_SESSION['id'])) {
  header("Location: index.php");
  exit;
}

if($_GET['id'] != ''){
	$rand = rand();
	$msg = '';
	$id = $_GET['id'];
$id=base64_decode($id);
	include "config.php";
	
	$query = mysqli_query($con,"SELECT * FROM app_category WHERE id ='".$id."'");
	while($row = mysqli_fetch_array($query)){
		$category_name = $row['category_name'];
		$category_image = $row['category_image'];
	}
	
	if(isset($_POST['update_category'])){
		$category_name = $_POST['category_name'];
		
		if($_FILES['category_image']['name'] != ''){
			$category_image = $rand."_".$_FILES['category_image']['name'];
			$full_path = IMAGE_PATH.$category_image;
			$update = mysqli_query($con,"UPDATE app_category SET category_name='".$category_name."', category_image='".$full_path."' WHERE id='".$id."'");
		}
		else{
			$update = mysqli_query($con,"UPDATE app_category SET category_name='".$category_name."' WHERE id='".$id."'");
		}
		
		if($_FILES['category_image']['name'] != '' && $update != ''){
			$name = $rand."_".$_FILES['category_image']['name'];
			$size = $_FILES['category_image']['size'];
			$type = $_FILES['category_image']['type'];
			$tmp_name = $_FILES['category_image']['tmp_name'];


			 if (isset($name)) 
			{
				if (!empty($name)) 
				{
					if(move_uploaded_file($tmp_name, PDF_UPLOADS. $name))
						$msg = '<p class="success">Your category is updated. Please go <span class="back"><a href="category.php">back</a></span> or open Category again to see it.</p>';
					else
						$msg = "<p class='login_error'>Your Category is not updated</p>";
				}
				else 
				{
					$msg = '<p class="login_error">Please choose image</p>';
				}

			}
		}
		else if($update != ''){
			$msg = '<p class="success">Group updated Successfully! Please go <span class="back"><a href="category.php">Back</a></span> or open <span class="back"><a href="category.php">Church Groups</a></span> again to see it.</p>';
		}
	}

?>
<!DOCTYPE HTML>
<html>
<?php include "header.php"; ?>
<body>
   <div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<?php include "main-header.php"; ?>
					<!-- //header-ends -->
		   				<div class="container breadcrum-wrapper">
							<div class="row">
								<div class="col-md-12">
									<div class="col-md-12">
										<h3 class="breadcrumbs-title">EDIT CHURCH GROUP</h3>
										<ol class="breadcrumb">
											<li><a href="dashboard.php">HOME</a></li>
											<li><a href="#">ABOUT</a></li>
											<li><a href="category.php">CHURCH GROUPS</a></li>
											<li><a href="news.php">NEWS LIST</a></li>
											<li><a href="notification.php">PUBLISH NOTICES</a></li>
											<li><a href="admin.php">UPDATE PROFILE</a></li>
											<li><a href="http://www.cocin.org" target="_blank">VISIT COCIN WEBSITE</a></li>
											<li><a href="statistics.php">STATISTICS</a></li>
											<li><a href="category.php">GO BACK</a></li>
											<li><a href="logout.php">LOGOUT</a></li>
											<li><a href="#" class="active_page">EDIT GROUP</a></li>
											
										</ol>
									</div>
								</div>
							</div>
						</div>
						<div class="outter-wp">
							<!--//outer-wp-->
							<div class="card-panel">
								<div class="row">
									<div class="row">
										<div class="col-md-12">
											<form method="post" enctype="multipart/form-data" id="category_form">
											<?php if($msg != ''){
													echo $msg;
												}
											?>
											<div class="form-group col-md-12">
												<label>Group Name</label>
												<input type="text" class="form-control" name="category_name" id="category_name" required value="<?php echo $category_name; ?>">
											</div>
											<div class="form-group col-md-12 image_show">
												<img class="img-responsive" width="150" height="150" src="<?php echo $category_image; ?>">
											</div>
											<div class="form-group col-md-12">
												<label>Image</label>
												<input type="file" name="category_image" id="category_image">
											</div>
											<div class="col-md-12">
												<input type="submit" name="update_category" value="UPDATE" class="right">
											</div>
										</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						 <!--footer section start-->
							<?php include "footer.php"; ?>
						<!--footer section end-->
					</div>
				</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
				<?php include "sidebar.php"; ?>
</body>
</html>

<?php
}
?>