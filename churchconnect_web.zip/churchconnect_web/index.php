<?php
/****************************************************************************/
/****************************************************************************/
//******** This is a project work designed by Billy Panshak Shippi*************/
//******** Student of the Department of Computer Science University of Jos**********//
//******** This is the index form that shows up on first launch of the application. It allows the user to login and access the application's home page************//
//******** to carryout content management privilleges...********** //
/****************************************************************************/
/****************************************************************************/

session_start();
error_reporting(0);
include "config.php";
?>
<?php	
if(isset($_POST['user_login'])){
	$user_email = $_POST['user_email'];
	$user_pwd = md5($_POST['user_pwd']);
	//$user_email=filter_var($user_email, FILTER_SANITIZE_EMAIL);
$remove[] = "'";
$remove[] = '"';
$remove[] = "="; // just as another example
	if($user_email != '' && $user_pwd !=''){
		$query = mysqli_query($con,"SELECT * FROM app_login WHERE email='".$user_email."' AND password='".$user_pwd."'");

		if(mysqli_num_rows($query) > 0 && mysqli_num_rows($query) == 1){
			while($row = mysqli_fetch_array($query)){
				/*if($row["active"]!= 1){
					$msg = '<font color=red size=3>Sorry,your account hasn\'t been activated!!<br>
							Please Contact the General Secretary of the Church for activation.</font>';
				}*/
				//else{
					$_SESSION['id'] = $row['id'];
					header("Location: dashboard.php");

				//}
				
			}
		}
		else{
			$msg = 'Invalid email address or password';
		}
	}
	else{
		$msg = "You need to enter username and password";
	}



}
?>	
<!DOCTYPE HTML>
<html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Augment Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<!-- //lined-icons -->
<script src="js/jquery-1.10.2.min.js"></script>
<!--clock init-->
</head>

<style>
h2.inner-tittle.page {
	left: 10% !important;
	font-size: 2em !important;
}
</style>

<style>@import url(https://fonts.googleapis.com/css?family=Droid+Sans);
.loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('http://www.downgraf.com/wp-content/uploads/2014/09/01-progress.gif?e44397') 50% 50% no-repeat rgb(249,249,249);
}

</style>
<div class="loader"></div>
<script>$(window).load(function(){
     $('.loader').fadeOut();
});</script>	
<body class="ash">
								<!--/login-->
								
	<div class="error_page">
							<!--/login-top-->
												
	<div class="error-top">
		<img src="logofinal.jpg" class="img-circle" width="150" height="150"  alt="Chania">	
		<div class="login">
			<h3 class="inner-tittle t-inner">COCIN LCC MADO ChurchConnect App <br> Admin Panel</h3>
			<h3 class="inner-tittle t-inner">Login</h3>
			<?php
				if(!empty($msg)){
					echo "<p class='login_error'>".$msg."</p>";
				}
			?>
															
			<form method="post">
				<input type="text" class="text" placeholder="Enter email address here" name="user_email">
				<input type="password" placeholder="Enter Password here" name="user_pwd">
				<div class="submit"><input type="submit" value="LOGIN" name="user_login"></div>
				Forgotten <a href="recover.php?mode=password">Password</a>?
				<p class="sign">Do not have an account? <a href="register.php">SIGN UP</a></p>		
				<p> &copy Billy Panshak Shippi</p>
				<div class="clearfix"></div>
			</form>
		</div>											
	</div>												
	</div>
<!--footer section start-->
	<div class="footer">
	</div>		   
	<!--footer section end-->
	<!--/404-->
<!--js -->
									
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
</body>
</html>