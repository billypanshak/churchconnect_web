<?php
error_reporting(0);
session_start();
include "config.php";
if (!isset($_SESSION['id'])) {
  header("Location: index.php");
  exit;
}

?>
<!DOCTYPE HTML>
<html>
<?php include "header.php"; ?>
<body>
   <div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<?php include "main-header.php"; ?>
					<!-- //header-ends -->
					
				
		   				<div class="container breadcrum-wrapper">
							<div class="row">
								<div class="col-md-12">
									<div class="col-md-12">
										<h3 class="breadcrumbs-title">NEWS LIST</h3>
										<ol class="breadcrumb">
											<li><a href="dashboard.php">HOME</a></li>
											<li><a href="about.php">ABOUT</a></li>
											<li><a href="category.php">CHURCH GROUPS</a></li>
											<li><a href="#" class="active_page">NEWS LIST</a></li>
											<li><a href="notification.php">PUBLISH NOTICES</a></li>
											<li><a href="admin.php">UPDATE PROFILE</a></li>
											<li><a href="http://www.cocin.org" target="_blank">VISIT COCIN WEBSITE</a></li>
											<li><a href="statistics.php">STATISTICS</a></li>
											<li><a href="dashboard.php">GO BACK</a></li>
											<li><a href="logout.php">LOGOUT</a></li>
										</ol>
									</div>
								</div>
							</div>
						</div>
		   
					   
						<div class="outter-wp">
							<form method="post" class="search_bar">
								<table>
									<tbody>
										<tr>
											<td>
												<div class="">
													<a href="add-news.php" class="add_news">Add New News</a>
												</div>
											</td>
											<td>
												<div class="">
													<input type="text" class="validate"  id="myInput" onkeyup="myFunction()" placeholder="Instant Search." title="Type a name ">
												</div>
											</td>
											<td>
												<div class="">
					<i class="fa fa-search" aria-hidden="true"></i>
												</div>
											</td>
										</tr>
									</tbody>
								</table>
							</form>
							<!--//outer-wp-->
							<div class="card-panel">
								<div class="row">
									<div class="row">
										<div class="col-md-12">
											<script>
function getresult(url) {
	$.ajax({
		url: url,
		type: "GET",
		data:  {rowcount:$("#rowcount").val(),"pagination_setting":$("#pagination-setting").val()},
		beforeSend: function(){$("#overlay").show();},
		success: function(data){
		$("#pagination-result").html(data);
		setInterval(function() {$("#overlay").hide(); },500);
		},
		error: function() 
		{} 	        
   });
}
function changePagination(option) {
	if(option!= "") {
		getresult("getnews.php");
	}
}
</script>

         
            
                
               
             
            <div id="overlay"><div><img src="loading.gif" width="64px" height="64px"/></div></div>
<div class="page-content">
	<div style="border-bottom: #F0F0F0 1px solid;margin-bottom: 15px;">
	Pagination Setting:<br> <select name="pagination-setting" onChange="changePagination(this.value);" class="pagination-setting" id="pagination-setting">
	<option value="all-links">Display All Page Link</option>
	<option value="prev-next">Display Prev Next Only</option>
	</select>
	</div>
	
	<div id="pagination-result">
	<input type="hidden" name="rowcount" id="rowcount" />
	</div>
</div>
<script>
getresult("getnews.php");
</script>	   				 <!--footer section start-->
							<?php include "footer.php"; ?>
						<!--footer section end-->
					</div>
				</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
				<?php include "sidebar.php"; ?>
</body>
</html>
