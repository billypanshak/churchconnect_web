<?php

$con = mysqli_connect("localhost","root","");
mysqli_select_db($con,"churchconnect_web");

define("DOC_ROOT", $_SERVER['DOCUMENT_ROOT']."/churchconnect_web/");
define("PDF_UPLOADS", DOC_ROOT."uploads/");
define("PROTOCOL","http://");
define("UPLOAD_FOLDER","/uploads/");
define("SERVER","/app_dashboard");
define("IMAGE_PATH",PROTOCOL.$_SERVER['SERVER_NAME'].SERVER.UPLOAD_FOLDER);

?>
<?php
class DBController {
	private $host = "localhost";
	private $user = "root";
	private $password = "";
	private $database = "churchconnect_web";
	private $conn;
	
	function __construct() {
		$this->conn = $this->connectDB();
	}
	
	function connectDB() {
		$conn = mysqli_connect($this->host,$this->user,$this->password,$this->database);
		return $conn;
	}
	
	function runQuery($query) {
		$result = mysqli_query($this->conn,$query);
		while($row=mysqli_fetch_assoc($result)) {
			$resultset[] = $row;
		}		
		if(!empty($resultset))
			return $resultset;
	}
	
	function numRows($query) {
		$result  = mysqli_query($this->conn,$query);
		$rowcount = mysqli_num_rows($result);
		return $rowcount;	
	}
}
?>