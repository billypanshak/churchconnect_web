-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 09, 2021 at 09:24 AM
-- Server version: 5.7.33
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `churchco_app_dashboard`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_category`
--

CREATE TABLE `app_category` (
  `id` int(255) NOT NULL,
  `category_name` varchar(300) NOT NULL,
  `category_image` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_category`
--

INSERT INTO `app_category` (`id`, `category_name`, `category_image`) VALUES
(2, 'CHOIR', 'http://www.churchconnect.org.ng/app_dashboard/uploads/1977793585_choir.jpg'),
(3, 'YOUTH FELLOWSHIP', 'http://www.churchconnect.org.ng/app_dashboard/uploads/1784322006_youth.jpg'),
(4, 'WOMEN FELLOWSHIP', 'http://www.churchconnect.org.ng/app_dashboard/uploads/934067444_Default.png'),
(5, 'MEN FELLOWSHIP', 'http://www.churchconnect.org.ng/app_dashboard/uploads/761015099_Men.jpg'),
(6, 'BOYS BRIGADE', 'http://www.churchconnect.org.ng/app_dashboard/uploads/1605607328_boys brigade.jpg'),
(7, 'GIRLS BRIGADE', 'http://www.churchconnect.org.ng/app_dashboard/uploads/1884211816_1775187377_girls brigade.gif'),
(8, 'SUNDAY SCHOOL', 'http://www.churchconnect.org.ng/app_dashboard/uploads/1155578103_4575choirday.jpg'),
(9, 'CONGREGATION', 'http://churchconnect.org.ng/app_dashboard/uploads/567786890_portfolio-1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `app_login`
--

CREATE TABLE `app_login` (
  `id` int(255) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_login`
--

INSERT INTO `app_login` (`id`, `email`, `password`, `active`) VALUES
(1, 'billypanshak@gmail.com', '5fd6a34dad0c60a33413122b296f55bc', 1),
(2, 'peterdogo61@gmail.com', '4bb85be5cc7f85e9045deb754acbe5c7', 1),
(3, 'dogoernest@yahoo.com', '0018bedd3f4f2d51c5959d167b990d67', 0),
(4, 'walbepeter61@gmail.com', 'a4e75767a263f06cfdd3259697c43fac', 0),
(5, 'johnzacks5@gmail.com', 'c73a5ec6875d7a8829e49c723dde3e5a', 0),
(6, 'anitapeej@gmail.com', '427b9fbaaa5a3aa5c29dd925423f6804', 0),
(7, 'Bitmanbit@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 0),
(8, 'tawe4christ@yahoo.co.uk', '35783e90d72db5d11f6f55883fad51e9', 1),
(9, 'billymanji@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 0),
(10, 'panshak@gmail.com', '5fd6a34dad0c60a33413122b296f55bc', 0),
(11, 'billyonline@gmail.com', '5fd6a34dad0c60a33413122b296f55bc', 0);

-- --------------------------------------------------------

--
-- Table structure for table `app_news`
--

CREATE TABLE `app_news` (
  `id` int(255) NOT NULL,
  `title` varchar(300) CHARACTER SET utf8 NOT NULL,
  `category` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `image` varchar(500) NOT NULL,
  `description` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_news`
--

INSERT INTO `app_news` (`id`, `title`, `category`, `date`, `image`, `description`) VALUES
(1, 'Notices For this Sunday', '1', '2018-03-04', 'http://www.churchconnect.org.ng/app_dashboard/uploads/2250Default.png', '&lt;p&gt;This is to inform all members to pray for the forthcoming RCC Gigiring planned outreach slated for&amp;nbsp;7-12th March,2018. The venue is Mambila Plateau inTaraba State.&lt;br /&gt;\r\n2.This month is special to the COCIN Men Fellowship worldwide. Here in Mado,the Men Fellowship is soliciting for your prayers,presence and every support for the success of the occassion. The date is&amp;nbsp;18.3.2018.&lt;br /&gt;\r\n3.The Church Auditorium project will commence in earnest this year. At the last Church Assembly that took place a couple of weeks ago, it was resolved that #1000 contribution by each for 3months will commence immediately. The percentage free offering is slated for&amp;nbsp;Saturday 18.6.18.&lt;br /&gt;\r\nMembers should ensure that they contribute sacrificially toward the project through their Groups of 100s.&lt;br /&gt;\r\nFrom:The LCC Secretary, Elder Peter Dogo&lt;/p&gt;\r\n'),
(2, 'HOLY COMMUNION', '1', '2018-03-18', 'http://www.churchconnect.org.ng/app_dashboard/uploads/8180communion.jpg', '&lt;p&gt;There will be combine Holy Communion (English and Hausa) service next Sunday 25/03/2018. All communicant members are to get prepared for that Fellowship&lt;/p&gt;\r\n'),
(3, 'SEND OFF PRAYER', '1', '2018-03-18', 'http://www.churchconnect.org.ng/app_dashboard/uploads/6346IMG-20180321-WA0044.jpg', '&lt;p&gt;Send off prayer of sister Mary N. Tyem comes up on Thursday 23/03/2018 at 3pm in the Church auditorium. God bless you as you avail yourself for the prayer.&lt;/p&gt;\r\n'),
(4, 'GOOD FRIDAY', '1', '2018-03-18', 'http://www.churchconnect.org.ng/app_dashboard/uploads/611819958_good friday.jpg', '&lt;p&gt;Good Friday comes up on the 30th of March, 2018. There will be combined&amp;nbsp; service which will commence at 8:30am on that faithful day&lt;/p&gt;\r\n'),
(5, 'APOLOGY', '1', '2018-04-18', 'http://www.churchconnect.org.ng/app_dashboard/uploads/5844apolo.jpg', '&lt;p&gt;The ChurchConnect team sincerely apologizes to COCIN LCC Mado for the absence of notices relating to the welfare and growth of the Church for some time; reason been that there has been some technical problem associated with the apllication however, the problem has been rectified!!&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;p&gt;Notices will be subsequenlty uploaded&lt;/p&gt;\r\n\r\n&lt;p&gt;Regards...&lt;/p&gt;\r\n\r\n&lt;p&gt;From Billy Panshak Shippi (CEO Team ChurchConnect)&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n'),
(6, 'COMBINED CHURCH SERVICE', '1', '2018-05-03', 'http://www.churchconnect.org.ng/app_dashboard/uploads/7877default.png', '&lt;p&gt;There is going to be a combined Church Service this Sunday the 6th of May, 2018. Time for the service is 8:30am.&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;p&gt;All members should please take note and try as much as possible to past the information to others.&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n'),
(7, 'OPERATIONAL KICKOFF', '1', '2019-02-28', 'http://www.churchconnect.org.ng/app_dashboard/uploads/4996download.jpg', '&lt;p&gt;We sincerely apologize for the absence in notifications and operations of the&amp;nbsp;churchnect app due to some unforseen circumstances.&lt;/p&gt;\r\n\r\n&lt;p&gt;It is our pleasure to announce to you that these circumstances have been rectified and notifications would be posted to you soonest.&lt;/p&gt;\r\n\r\n&lt;p&gt;Thank you&lt;/p&gt;\r\n\r\n&lt;p&gt;Billy Panshak Shippi (CEO Team Churchconnect)&lt;/p&gt;\r\n'),
(8, 'ChurchConnect App Fully Back ', '1', '2020-03-15', 'http://www.churchconnect.org.ng/app_dashboard/uploads/27954996download.jpg', '&lt;p&gt;Team Churchconnect wishes to extend an apology for the inactivity in the operational activities of the application developed for the dessimination of information to Church Members of COCIN LCC Mado, Tudun Wada Jos.&lt;/p&gt;\r\n\r\n&lt;p&gt;We are happy to notify you all that the application is up and fully functional with a lot of beautiful and user friendly features.&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;p&gt;Thank you for your understanding&lt;/p&gt;\r\n\r\n&lt;p&gt;Billy Panshak Shippi (CEO Team ChurchConnect)&lt;/p&gt;\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

CREATE TABLE `devices` (
  `id` int(11) NOT NULL,
  `token` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `devices`
--

INSERT INTO `devices` (`id`, `token`) VALUES
(21, 'eD3QI5BC_A4:APA91bFYx137ZweK3cPPXGnuMw7WGD0rMQm4EwinN0bGdrQGCfRUnpv9inLnSrsicLMB97RJnD-9QQjS6nReABun9HvNlA9mTQJLd7uaaByMk0WUP8sKNHjxZegtB-0jFar6d16HXN09'),
(22, 'cZBovMeCUUY:APA91bEQG9f0eYkRonGyxoZA90zhvj7Uv96gN1QfTe5FRXnLk5tuzEHMViXbZGhQrMt-_MD9lKDRm_JpeY8SnOc1hu7jQle4TFZlLgEQtbTz1ZVrIhGcQiBaZ9aD3V8W87iOmBB_fEuL'),
(23, 'cCtRodlfwN8:APA91bGZUwqqVtD9UKUGcV1x1ksGs_FI8NBnCcfMwQ-FFUbfcptX-It-m6tr_ado9OtaBc-uFTM10N00qzkq3U7wCN2atwZBziiwyw8yl5YMYrThTwgoCxjNwN0vKKOaeuMWim7X2mgx'),
(24, 'fndxZVzy91g:APA91bGiO6MxRcJN4_0wKshPb_4ht9DhqrOkt4GYHzX479G_dPQzsSCBO2z2H6ue7J00l9DyRs5AWR8QnUAJ-W8adJF2aq_bwTiPtifs76vKeGxzsKc5tNPo3q7T75IL7wz2Me17diwk'),
(25, 'c-v8hTEuss8:APA91bH4SfrcMkunJ3mLaT9vXqTgCp_rjuAyyoQQE951rG9rQqYUpqi9BIZTRIMueQ3oMst1eAdJQzAbtp1_4LUMkmZlA_fj5I8DkGeBdMHfSU5uJ7y3pO6ZInAn0hSxaEUekI-ElM-S'),
(26, 'ea0d_BjocmQ:APA91bEH4VF2gdXxkwubIBxKo9ackzruufcr19g5CmeT3ArwN6xIV9pXMG4cjNB9XC8BgZsBI-orV3x5r6p7fzZS8huioOar8J7G9b-QhnwjyAWVZJfA4NIOGZwoIU_i_lWtfis4zD5G'),
(27, 'fiAUwwpGSHE:APA91bGC_f6I6kvcefrJi5jtTh9P1TSKjsrT3w5P0aZN5N2-1gxBY4FhInKyzPGmLytaFZgTtcHh9NsxSQvFiHaCCNletzKEhz6XqgoG5euIXHqX0Pb5WGCOMpfa6HOMW8Hiu4e0s3gs'),
(28, 'cexHhDAOZAw:APA91bFF6wv9u2lb78Lw_Ub6KVb8DpdN9-OfwimK_U_zfAASinNc3v0q3QERbLEpQPB3Bachu_TV-JnaIuF7zo25WRC20n1Zy5CJawkrDTz0YaUarWQXoRU_7GfC9kL_0cLnsaXZEzVW'),
(29, 'eVOZE3rNZms:APA91bFaAUnNc82ldxlWIowH5_0wwQFruepknt_4xcvcUsieqGZ2bihemEi_Vfrw500nWEOVqs_ux1CIVjf04k3bFZ3ZL8e5QOrF9k7G6KwhyNP3RPvhD4GQuBvPN73ZNvYS0FLg2HNh'),
(30, 'cyR3f_pKj4U:APA91bFmKBpyJpMuFpGKCbkqQBicJQHF42LJEiNfjXptXa5PP8DlLYW9j-JpsoMUe7XUdzATPH-0a04YFx_hQeDiS1Q9E4HW45XKHDZ_PKEk2JnaFZOVTH6DhUGLngFKWRYGckGAopYB'),
(31, 'e7kha_F5gwk:APA91bGnhfFLPNBxeGL2-vtXVCKv6h27YKExzAkC6gAoC-oNYXPtmsfpbdLjJHko2ldrDlK3cFy7NzuR6QM0SqkxOKAZE2kUJT1GB_dDu6H0yR9-Er-VR6GGh3FcZRSx0rss9By0FEg1'),
(32, 'cMJ2ecC4qbs:APA91bGPDrLErZJcd9zC91M018NwgXMxHOOdOewZ--tFHlO9LXkeXVWUo_eSNRp_HtBuo5K0nc0GZyLV1yM3mPG4fUgyEwWcnvdwfV6ziCSUbHvnXhjYrUQ0I9FgH_qrj9qSW-w9k03L'),
(33, 'f-Xpr9p49gc:APA91bE5yfJkLH1Oy-TBq-mf0ZEWkuER9i9N_2UE57PaLEVSaSSF99Myp5LUclH7SCwgfOkRySlEsOXOkITjZFNrBH5RpU_lUTxbo4HgKiuoTQhODHWZBt2EWxzeXh8FnCQ5IezN3spV'),
(34, 'fGy_7gM5Egs:APA91bHwkyOckIqxr2oZEg1Hd4XqHcwsXtbq4gIaFW_y2nita8lGS67ECauv0LfDCh1Q4qI8YIF3lBKAOKFNKX26YuHXA1Mj_itKBBwgWkC910qnhBXJ68cLekyfAN1Mp2az0_dnlz0t'),
(35, 'dpRDYo6V57Q:APA91bECh6QwQEo017xbLRqq8NBVUbcgMupjKpwmA28UH6-NY8se3kUDCCOhsLOvM1vyIvKNzQ9mBe8Qf-zPmqB1SfngONF16i6MPqFyc2Udip_7QyfIzjXpEH3COBrc5fubZrxYkReK'),
(36, 'dCnIEOcnlHY:APA91bGcCQWk9-hZ-EQpTiZnfYodQUwviuHvy9ZGi5m7ArQzOyrx3pbQHaZOtDRxoEk7Ol8RDMA9UP5sTpNpdW11jtbWOCg1YPMmuJrH1kcQarXFLwdnhJRjDWrh3StH1jhpwLBN_rEl'),
(37, 'fTIRkbc0s1E:APA91bF7yHpYM-SetD68KRzb-yIKXYWa9N-LdbvPFe8r4pul2X0HmrRRNnAUQ6tw_B38I8v31rl_SKl87OOtOEghWzTiLyRGJ-2Mz4IrWgws7Z2GaGKxIomJPV0YAVeAXBMwIvPNx4qi'),
(38, 'c0uTM2Lr2no:APA91bGg9yBqFehZgxqhiLlsQ89ddN9Dezpg2wXvKEXHCRkRVvh4Su88StoVLyFfXbQzroApOiqYQxh4fpQsHAp5XBy9ghhcW3XScV3XtNHmaAeq1EMNR4I2H2KeRhri41ebaYtYl6T4'),
(39, 'dAQ0IFlV9ns:APA91bFcPfNJxZuz-sIa8sIuEUnhwRqhoagTEA_FFRyI4qibdnTy1oB1aZwr2uu0ANryEG3x6rfv3I8srhhNCBQEK79K5rcuxHdgc9LsvBXNh42eDFwfQzOkY-G6LBmd066KE0TMB3T3'),
(40, 'cSm88JXbZpk:APA91bF2jiger2ur74UTMcuNN440iZ3ILHVSrF6YJaquq9gxrH-PhzA0joYithgArDjYBfs1pkoMqDITA85QF8rm45gnIO6hmuqoDReuaWuv5KtniKRw8mEmy_kA_DqzkDVXFjriGthR'),
(41, 'ckJBLmauQWE:APA91bEHRw3rymdEUdMy4C8F73rTxanEpaZ3puQ7CdYxb_r-EshF9QD9wca_1CtcahOhmucseMiekxUrXd8qgKa3a9Q3O404aBw2f_EUAwPYj1idhER4N1WPTwQ8-FvgUKYvSrVYoX1h'),
(42, 'c6exVTd2MNA:APA91bHitXDnGN-t3qJN-0ZvjPqWBMJKz0ZwGamOD5Zu5PyNYKw6Zl-D5nEI-_WO4pXSkJgQog-ktI-F7hT9kxffLaEYWBsH_JfcqP7SN7YcutHWBLjeFo0tIVK-bZZ0IMt3gIvrwsKk'),
(43, 'd6AO4GXcBuo:APA91bGXsHhrSSkKOTQRuAo5D9lUBj6nCz6JfkMWDvUD9CVfKKx_GdQSuKXeZNSlsKNPXzLL817hrFLljmNgJY8scLJqhJwM_JR0fl6gxhoncdDsglIGDYpRmD6zpSSUpNy0sfP26hdp'),
(44, 'ddCMUhhPlkw:APA91bGyLm9-4HfZXIGunNfgrg9pn2StJ2cHnYEpcDl_71XgXXlCnJJsCNJ1EbCkMZTw7_kCyOVWlsHoK1-cVvkHyLlEL5WDpIg7054Jmn1wPonQr5XRINvAcDwYy3L2wF6EC88rfeUE'),
(45, 'c4MOIhK0imA:APA91bEalmfjtscq9G3G_9foPNj72lGe54k1FWy0RhK8QlhRJ__NjdSytoFIoM32vmpX62ev2wBdPv98RFVwnbSUTbIG8Y2H0Ld6WRcVv2TdlGBlW09xdx83dI8QuZvOlPtQO5asvLHE'),
(46, 'fHeeKcN7TKw:APA91bHizM-uSHUhHqtjITTOqWt-tqEkeNKseIepjwDqPLV_jbV1Tn1CDgRcvdXBSPw6ieBUrO_HdHD55i4qHovq3W1Kj0i3xeDZDEgH9Jqxia-Z926GB0NcX5I0XpNU5m6f7tDDMi7y'),
(47, 'cZaAdglqZK0:APA91bGANlms64cIQSjqz7YGjs9LsdqhpSs-mgkOBI_DK5VmYuYpWKnMWJpJ6mdpxgJJttAtLJgaGpXRgtBQz5kweygtEqQ1UqR8zWMfktRVm2BKOqLmMg-u0o4l-FcdbbSemc467o0Y'),
(48, 'fmz-wq99fag:APA91bGGRfLde_3ujTZw6lM74yh0LOoVirvRQk3s7-6KBtjlhzj9Q8xwU8cdVSxBCL_2XnJruIE3Vi3y5_-2tVU-xjEUHnSiJGDoXHVJHCqUeN-_AeV3pXl5Z6ltUvFchtfa4VuZbsqb'),
(49, 'fTxTmt16yh0:APA91bFdFqLTh5nSmwowyi1m6SZA0mnr_3S2KrGZHFGkaFwCmr045kj_q5burw5i5Xz-7OH4tbCxrd8XU_pfktq5EBiQ6qUESxiyGkidSSgAN9MDHNHnpT2cnzjosilt0ZFa4MSK8c5P'),
(50, 'dMqbtwin7TU:APA91bETKWJsbZUmXogy13p-454qR0C9JnWHyMTS6T9VvI29rPVj0mja_6WIFevpiGn_seOiz3aiOB7l4c5qBIbyw2ItdICKljIhrdYylmZnQCRNJdnq5OKjkzD6m8sv2-3RG9KwWJ2D'),
(51, 'ehnfnUILQhs:APA91bGfu-Q0KdorCz1x127TB7PfGctPwx7pLeGxbJBiP5PF_8MuBhgMi12_50IWo-b9TixfwSqZ2tChMFy3QKiy_x0ZblVOWzMtETjpNTNs3-VeeGqR--WMppaYMiE4UgPH9IGDi6oS'),
(52, 'ff02HgRgx_4:APA91bGU17rf0GgPVBfWEZnCDLXnOHwkNiXYpIJqxSy7sSYvblf8kFybYc2femzJN6lUyYEwdK8i36cdkU8F9z1eul2TAcUpD8laLB_dXp1xUitY5hWvNtzlMg70UcMRpOP7rVgECsiN'),
(53, 'cjjN0wXZIWA:APA91bHPmq_sI2oPD4nYEWSqdCwHUbpjhH5l10SNuTdcOlNqERUxTJLiFvFDJGFju_m66_YW4mauZb27Rx1qWEKVHZxDE5jyunkHKDONRfLf8hX2A2UJwYmeXQP8AwLDmONsn4Yf2R1l5PySor3OgJGPvk2I16O_rw'),
(54, 'e-mN9EvBqCA:APA91bH59EapmGRZdz5OTDHMwDKly0VjMkK63hps_inMWUNSC8qQYOQSCFe8Zz0lITuweuLjOTda_RVm0m290JuxBBXIK7nLelAlCmoW2rTns5Rxn42BcmoN1HWb_FlDAa0G07tVrfS0_m2VAXec2JjCdVqjL5VrvQ'),
(55, 'cCmNNfFGLVc:APA91bEpSfh7p0LUEL-DT8HyGzOZPekzyPrxrnkzdNVYgoLYf9M_ixUUaZOdaMQgrV4sOJx3jkfBFhvhbRAaH2G3ODFZSq_lnbKD5jCJ4cfMUdavGxaktJP7pem1V0AQGqNx4DASpDK7LM8OpeXBy-gatM5BvUyEzQ'),
(56, 'cJAXpcLcBU4:APA91bEiftvJ_k5FEI9e8wTsEhpzN09zRFZzCGov_to6Q3lyfr2kILcaB3Zcu59htrI-ZB3a7UcmQtAteBwCm-K0psB6THXIY0tVmBIAkk95EDuAnOYwjEOq_V84oF8nCfjOrGU8_2nY'),
(57, 'eozJCLgario:APA91bG-3RT7_wQmMU6KDO1mEx7eFbpMnysnPk1I2vR3wRcaewz3wX_oIY_4NFoSfT-qQDXTJEpImddi4iwwHohz4UtJ0aeVKc6_dN1Y_1VF61Vs4wSAXohy2Zr6jR3H0BekBidb6_ol'),
(58, 'eDfr7M-m5NE:APA91bGmbizf9qP_ASc_HPuKRdPuqPYLtQE_QGgWeZiCVv5lj6PqfFv9coH4Q6U3Z5G3lrtK7Bw312-u-ZmQQ2popNwFU5XWDHnAS85rvFTYdDzywc9WOAr5xZ99CMVCqjxvduY6Z37m'),
(59, 'd7woLBSciKw:APA91bGVSOHi5mtN_yDe3Bt-Q0kU4qbC1NoKeeG4UBo_kXnXwej2SGIUjCtqLPWJ8_FnypO2VQGB_Z6DYl567JCmd0KnwX1Gmx0n29Bbwnc-xUA4P1nLVDnysftu5I8M2zGm-LsL68AN'),
(60, 'd-JeejeuiU0:APA91bHcQ9eaODe0zDGMqNG_jCYQNfl4zxF716IDkHQGvOqEfFSS3Nd_KN0YXn7SpIp9wiKMmxlpEEqaDYLzENWaq1nD4-9DUeG_qONIt31zb93y4JfVsLL_lEO7XC_hC6dI0VGDvstK');

-- --------------------------------------------------------

--
-- Table structure for table `minutes`
--

CREATE TABLE `minutes` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `created` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_category`
--
ALTER TABLE `app_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_login`
--
ALTER TABLE `app_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_news`
--
ALTER TABLE `app_news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `devices`
--
ALTER TABLE `devices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `minutes`
--
ALTER TABLE `minutes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_category`
--
ALTER TABLE `app_category`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `app_login`
--
ALTER TABLE `app_login`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `app_news`
--
ALTER TABLE `app_news`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `devices`
--
ALTER TABLE `devices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `minutes`
--
ALTER TABLE `minutes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
