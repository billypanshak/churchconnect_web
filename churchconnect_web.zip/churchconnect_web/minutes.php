<?php
error_reporting(0);
session_start();
include "config.php";
if (!isset($_SESSION['id'])) {
  header("Location: index.php");
  exit;
}
//fetch files
$sql = "select * from minutes";
$result = mysqli_query($con, $sql);
?>
<!DOCTYPE HTML>
<html>
<?php include "header.php"; ?>
<body>
   <div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<?php include "main-header.php"; ?>
					<!-- //header-ends -->		
				
		   				<div class="container breadcrum-wrapper">
							<div class="row">
								<div class="col-md-12">
									<div class="col-md-12">
										<h3 class="breadcrumbs-title">MINUTES UPLOAD</h3>
										<ol class="breadcrumb">
											<li><a href="dashboard.php">HOME</a></li>
											<li><a href="about.php">ABOUT</a></li>
											<li><a href="category.php">CHURCH GROUPS</a></li>
											<li><a href="news.php">NEWS LIST</a></li>
											<li><a href="notification.php">PUBLISH NOTICES</a></li>
											<li><a href="admin.php">UPDATE PROFILE</a></li>
											<li><a href="http://www.cocin.org" target="_blank">VISIT COCIN WEBSITE</a></li>
											<li><a href="statistics.php">STATISTICS</a></li>
											<li><a href="statistics.php">GO BACK</a></li>
											<li><a href="logout.php">LOGOUT</a></li>
											<li><a href="#" class="active_page">MINUTES</a></li>
										</ol>
									</div>
								</div>
							</div>
						</div>
		<!-- code for file upload-->

	<div class="container">
    	<div class="row">
        <div class="col-xs-8 col-xs-offset-2 well">
        <form action="uploads.php" method="post" enctype="multipart/form-data">
            <legend>Select File to Upload:</legend>
            <div class="form-group">
                <input type="file" name="file1" required/>
            </div>
            <div class="form-group">
                <input type="submit" name="submit" value="Upload" class="btn btn-info"/>
            </div>
            <?php if(isset($_GET['st'])) { ?>
                <div class="alert alert-danger text-center">
                <?php if ($_GET['st'] == 'success') {
                        echo "File Uploaded Successfully!";
                    }
                    else
                    {
                        echo 'Invalid File Type! File type must either be word documents, images or PDF';
                    } ?>
                </div>
            <?php } ?>
        </form>
        </div>
    </div>
    
    <div class="row">
        <div class="col-xs-8 col-xs-offset-2">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th><font color="black" size="3">ID</font></th>
                        <th><font color="black" size="3">File Name</font></th>
                        <th><font color="black" size="3">View</font></th>
                        <th><font color="black" size="3">Download</font></th>
                        <th><font color="black" size="3">Date uploaded</font></th>
                        <th><font color="black" size="3">Action</font></th>

                    </tr>
                </thead>
                <tbody>
                <?php
                $i = 1;
                while($row = mysqli_fetch_array($result)) { ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo $row['filename']; ?></td>
                    <td><a href="minutes/<?php echo $row['filename']; ?>" target="_blank">View</a></td>
                    <td><a href="minutes/<?php echo $row['filename']; ?>" download>Download</td>
                    <td><?php echo $row['created']; ?></td>
                    <td>
						<a href="#"><i class="fa fa-pencil" aria-hidden="true"></i>(Edit)</a>
						<a href="#"><i class="fa fa-trash-o" aria-hidden="true"></i>(Delete)</a>
					</td>
					

                </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>	          
                
 <!-- end of code for file upload -->       
             
          <!--footer section start-->
			<?php include "footer.php"; ?>
		<!--footer section end-->
			</div>
			</div>
		</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
				<?php include "sidebar.php"; ?>
</body>
</html>
